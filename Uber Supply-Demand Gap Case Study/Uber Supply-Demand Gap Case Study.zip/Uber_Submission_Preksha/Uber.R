## Name - Preksha Tiwari
## Module - Assignment - Uber Supply- Demand Gap
## Instructions - Set the working directory path and place the data file(Uber Request Data.csv) in the same path.

# Import the Uber data set in Rstudio in a variable named uber

## Setting working directory path
## read.csv() function is used to read given csv file into a data frame that it creates called uber.
## Argu-stringAsFactor is set as False so strings in a data frame is treated as just string not as a factor. 

uber <- read.csv("Uber Request Data.csv",stringsAsFactors = F)

## Libraries
 # lubridate is for function parse_date_time()
 # stringr is for function POSIXlt()
 # ggplot2 is for function ggplot()

install.packages("lubridate")
install.packages("stringr")
install.packages("ggplot2")

library(lubridate)
library(stringr)
library(ggplot2)

# Check for dulicate values which gives zero as output so there is no duplicate value in Request.id column
sum(duplicated(uber$Request.id))

##check for NA Values  
# No cleanup activities performed on driver.id and drop.timestamps columns 
# As expected both columns have NA values based on No cars available and Cancelled status  
# below sum commands gives output as zero so there are no NA values in below columns
sum(is.na(uber$Request.id))
sum(is.na(uber$Pickup.point))
sum(is.na(uber$Status))
sum(is.na(uber$Request.timestamp))

## check for cases on status and pickup.point columns in excel and found no in-consistency.
# Peforming format consistency on request.timestamp and drop.timestamp columns
# date format is presented in both format  by "/" as well "-".
# parse_date_time() function is used to formate date-time objects and returns standard format.

uber$Request.timestamp <-parse_date_time(uber$Request.timestamp,orders = c("d/m/Y H:M:S" , "d-m-Y H:M")) 
uber$Drop.timestamp <-parse_date_time(uber$Drop.timestamp,orders = c("d m Y H:M:S" , "d m Y H:M"))

## Derived column - Request.time on the basis of Request.timestamp
#format() function is used to get the time in a needed format

uber$Request.time <- format(uber$Request.timestamp,"%H:%M:%S")

#uber$Drop.time <- format(uber$Drop.timestamp,"%H:%M:%S")
# Derived columns Request.hours and date on the basis of Request.time using POSIXLT()

uber$Request.day <- format(as.POSIXlt(uber$Request.timestamp,format="%Y%m%d H:M:S"),"%D")
uber$Request.day <-parse_date_time(uber$Request.day,orders = c("m d Y" , "m/d/y")) 
uber$Request.hour <- format(as.POSIXlt(uber$Request.time,format="%H:%M:%S"),"%H")
uber$Request.date <- format(as.POSIXlt(uber$Request.timestamp,format="%Y%m%d H:M:S"),"%d")
uber$Request.weekday <- strftime(uber$Request.day,format = "%a")
  
#function is used to get the customized timeslot based on request.time column

Fun_timeslot <- function(P_timestamp)
{
  if (!is.na(P_timestamp) && P_timestamp >= "03:00:00" && P_timestamp <= "07:00:00")
  return("Early Morning")
  else if (!is.na(P_timestamp) && P_timestamp >= "07:00:00" && P_timestamp <= "11:00:00")
    return("Morning")
  else if (!is.na(P_timestamp) && P_timestamp >= "11:00:00" && P_timestamp <= "15:00:00")
    return("Afternoon")
  else if (!is.na(P_timestamp) && P_timestamp >= "15:00:00" && P_timestamp <= "19:00:00")
    return("Evening")
  else if (!is.na(P_timestamp) && P_timestamp >= "19:00:00" && P_timestamp <= "23:00:00")
    return("Night")
  else if (!is.na(P_timestamp) && (P_timestamp >= "23:00:00" || P_timestamp >= "00:00:00" || P_timestamp <= "03:00:00"))
    return("Late Night")
  }

# Derived column Request.timeslot using functions Fun_timeslot and Sapply().  
uber$Request.timeslot <- sapply(uber$Request.time,Fun_timeslot)

# Derived column - Route on the basis of pickup point which gives from and to datapoints.

uber$Route<- ifelse(uber$Pickup.point=="Airport","Airport to City","City to Airport")
uber$Request.timeslot <- as.character(uber$Request.timeslot)

# write.csv() function is used to write the data to the desired excel file which can be used for plotting in Tableau
# write.csv(uber,"Uber.csv")

########################################################################################################

# ggplot() is used to plot the specific values of a data frame. 
# geom_bar() is used to specify what kind of graph is needed. Since we are analysing the number of requests here ; hence bar graph would be the most suitable graph here. 
# facet_wrap() is used to plot more than one graphs in the same frame by a new different variable i.e. Request Date.
# labs() ii]s used to give names to the x axis,y axis and any other variables shown via fill in the graph. 

# Plot1 Trends for day and hours wise based on the requested status
# We are plotting hour wise Status of the Requests to identify daily trends of the cancellation or No Cars available for each day. 
# This will help us identify the time slots which contibute majorly to the supply demand gap.

ggplot(uber,aes(x=Request.hour))+geom_bar(aes(fill= Status),position="stack")+
  labs(x="Requested hours", y="Number of requests",title="Status wise daily and hourly trips trends ",fill="Status")+
  facet_wrap(~uber$Request.date,nrow = 5)+theme_grey()

#Plot2 Trends for day and hours wise based on the requested route
# We are plotting hour wise Route of the requests to identify the hour wise distribution of the routes for each day

ggplot(uber,aes(x=Request.hour))+geom_bar(aes(fill= Route),position="stack")+
  labs(x="Requested hours", y="Number of requests",title="Route wise daily and hourly trips trends ",fill="Route")+
  facet_wrap(~uber$Request.date,nrow = 5) +theme_gray()

#plot3 Day-wise trends for Demand & Supply
#here graph show total number of demand = 262+504+601=1367 on Monday and 240+505+562=1307 on Tuesday and so on
#we can say demand is relatively higher for Monday, Thursday & Friday

uber$Request.weekday <- factor(uber$Request.weekday,levels = c("Mon","Tue","Wed","Thu","Fri"))

ggplot(uber,aes(x=Request.weekday,fill=Status))+
  geom_bar(stat= "count",position="dodge")+
  labs(x="Requested days", y="Number of request",title="Day-wise trends for Demand & Supply")+
  geom_text(stat="count",aes(label=..count..,y = ..count..),position=position_dodge(width=1.0),vjust=-0.25)+
  theme_bw()

#Plot4 Binwise trends for Demand & Supply
# We observe surge in demand during "Early Morning" & "Morning" and  "Evening" & "Night" bins.
# here graph shows demand-total request as 375+300+464 =1139 in Early morning and 583+302_619=1504 in morning and so on

uber$Request.timeslot <- factor(uber$Request.timeslot,levels = c("Early Morning","Morning","Afternoon","Evening","Night","Late Night"))

ggplot(uber,aes(x=Request.timeslot,fill=Status))+
 geom_bar(stat= "count",position="dodge")+
  labs(x="Requested timeslot", y="Number of request",title="Bin-wise trends for Demand & Supply")+
   geom_text(stat="count",aes(label=..count..,y = ..count..),position=position_dodge(width=1.0),vjust=-0.25)+
    theme_bw()

#Plot5 plot between routes and number of requests on the basis of status for requested timeslot(Morning)
# Supply from Airport is 296+245 = 541  and demand is 541+547+59+896+75 = 2118,hence gap is 1577 i.e. 74.4%
## Unavailability of cars is higher in the evening on Airport to City route.

ggplot(subset(uber,uber$Route =="Airport to City"),aes(x=Request.timeslot,fill=Status))+
  geom_bar(stat="count",position="stack")+
  labs(x="Requested time slot", y="Number of trips",title="Route & Bin wise total request - Airport to City")+
  geom_text(stat="count",aes(label=..count..,y = ..count..),position=position_stack(vjust=0.6))+
  theme_dark()

#Plot6 plot between routes and number of requests on the basis of status for requested timeslot(Morning)
# Supply from Airport is 247+350 = 597  and demand is 597+229+274+365+559 = 2024,hence gap is 1156 i.e. 57%
## cancellation by driver is higher in the early morning and morning slot on City to airport route.

ggplot(subset(uber,uber$Route =="City to Airport"),aes(x=Request.timeslot,fill=Status))+
  geom_bar(stat="count",position="stack")+
  labs(x="Requested time slot", y="Number of trips",title="Route & Bin wise total request - City to Airport")+
  geom_text(stat="count",aes(label=..count..,y = ..count..),position=position_stack(vjust=0.6))+
  theme_dark()
